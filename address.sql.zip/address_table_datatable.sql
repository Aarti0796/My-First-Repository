
-- --------------------------------------------------------

--
-- Table structure for table `datatable`
--

DROP TABLE IF EXISTS `datatable`;
CREATE TABLE `datatable` (
  `ID` int(100) NOT NULL,
  `placename` varchar(100) NOT NULL,
  `monthName` varchar(100) NOT NULL,
  `cityname` varchar(100) NOT NULL,
  `timestamp` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datatable`
--

INSERT INTO `datatable` (`ID`, `placename`, `monthName`, `cityname`, `timestamp`) VALUES
(1, 'Amsterdam, Netherlands', 'march', 'Granada, Spain', '0'),
(2, 'Grand Canyon National Park, Arizona, USA', 'march', 'NB, Germany', '12'),
(3, 'New York, NY, USA', 'march', 'Nuremberg, Germany', '12:09:32 PM'),
(4, 'Houston, TX, USA', 'april', 'Hamburg, Germany', '12:47:23 PM');
